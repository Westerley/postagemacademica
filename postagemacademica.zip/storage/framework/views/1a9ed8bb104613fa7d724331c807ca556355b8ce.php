<?php $__env->startSection('content'); ?>

    <div class="col s12 m12 l4 descricao-perfil">
        <div class="card-panel white">
            <p> Vinculo:           <span>  </span> </p>
            <p> Nome:              <span> <?php echo e(Auth::user()->name); ?> </span> </p>
            <p> Email:  <span> <?php echo e(Auth::user()->email); ?> </span> </p>
            <p> Celular:  <span>  </span> </p>
            <p> Semestre:          <span>  </span> </p>
            <p> Posts Realizados:  <span>  </span> </p>
        </div>
    </div>

    <div class="col s12 m12 l8">

        <section>
            <div class="input-field col s12">
                <select>
                    <option value="" disabled selected>Disciplinas</option>
                    <option value="1">Option 1</option>
                    <option value="2">Option 2</option>
                    <option value="3">Option 3</option>
                </select>
                <label>Filtrar Por: </label>
            </div>
        </section>

        <br>

        <?php $__empty_1 = true; foreach($posts as $post): $__empty_1 = false; ?>

            <section class="section">

                <header>
                    <div class="chip">
                        <img src="/image/profile/user/sem_foto.png" alt="Contact Person">
                        <?php echo e(Auth::user()->name); ?>

                    </div>

                    <h5> <?php echo e($post->title); ?> </h5>
                </header>

                <article>
                    <p> <?php echo e($post->content); ?> </p>
                </article>

                <footer class="votacao">
                    <p>
                        <a href="#"> <i class="fa fa-thumbs-o-up fa-2x"> </i> </a> <span> (<?php echo e($post->like); ?>) </span>
                        <a href="#"> <i class="fa fa-thumbs-o-down fa-2x"> </i> </a> <span> (<?php echo e($post->unlike); ?>) </span>
                        <span class="download"> <a href="/download/<?php echo e($post->arquivo); ?>"> <i class="fa fa-download"> Download </i> </a> </span>
                    </p>
                </footer>

            </section>

            <div class="divider"> </div>

        <?php endforeach; if ($__empty_1): ?>
            <h5 class="center"> Nenhuma postagem realizada </h5>
        <?php endif; ?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.profile', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>