<!Doctype html>
<html lang="pt-BR">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/icon?family=Material+Icons" >
        <link rel="stylesheet" type="text/css" href="/css/style.css" media="screen,projection">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    </head>

    <body>

        <?php echo MaterializeCSS::include_full(); ?>


        <?php echo $__env->make('include.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <main>

            <div class="container">

                <div class="row white">

                    <?php echo $__env->yieldContent('content'); ?>

                </div>

            </div>

        </main>

        <?php echo $__env->make('include.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </body>

</html>

<script>
    $(document).ready(function() {
        $('select').material_select();
    });
</script>