<aside class="col s12 m5 l4">

    <p> Contribuidores </p>
    <ul class="collection">
        <li class="collection-item avatar">
            <img src="/image/profile/user/sem_foto.png" alt="avatar" class="circle">
            <span class="title"> Westerley Reis </span>
            <p> Programação OO </p>
        </li>
    </ul>

    <p> Postagens </p>
    <ul class="collection">
        <li class="collection-item avatar">
            <img src="/image/profile/user/sem_foto.png" alt="avatar" class="circle">
            <span class="title"> Jorge Delas </span>
            <p> Validações com JQuery </p>
            <p> 15/06/2016 <br>
                Likes: 20
            </p>
        </li>
    </ul>

</aside>