<footer class="page-footer #424242 grey darken-3">

    <div class="container center">

        <div class="row">

            <ul class="redes">
                <li> <a href="#"> <i class="fa fa-facebook"> </i> </a> </li>
                <li> <a href="#"> <i class="fa fa-twitter"> </i> </a> </li>
                <li> <a href="#"> <i class="fa fa-google"> </i> </a> </li>
                <li> <a href="#"> <i class="fa fa-envelope"> </i> </a> </li>
            </ul>

        </div>

        <div class="footer-copyright">
            Desenvolvido por:
                <a class="grey-text text-lighten-4" href="#!"> Bruno Santos </a> &
                <a class="grey-text text-lighten-4" href="#!"> Westerley Reis </a>
        </div>

    </div>

</footer>